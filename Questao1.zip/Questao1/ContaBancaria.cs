﻿using System;
using System.Globalization;

namespace Questao1
{
    class ContaBancaria {
        public int numero;
        public string titular;
        public double saldo;
        public double quantia;

        public ContaBancaria(int numero, string titular)
        {
            this.numero = numero;
            this.titular = titular;
        }

        public ContaBancaria(int numero, string titular, double saldo)
        {
            this.numero = numero;
            this.titular = titular;
            this.saldo = saldo;
           
            
        }

     

        public void Deposito(double valor)
        {
            this.saldo += valor;
        }

        public void Saque(double valor)
        {
            this.saldo -= valor;
        }

      
    }
}
